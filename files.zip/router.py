MEMORY_HINTS = (
    "who am i",
    "what is my name",
    "what's my name",
    "remember my name",
    "remember",
    "remember me",
    "history",
    "conversation",
    "previous question",
    "last question",
    "first question",
    "second question",
    "third question",
    "what was my third question",
    "what did i ask",
    "did i ask",
    "questions i asked",
    "last answer",
    "previous answer",
    "what did you answer",
    "your last answer",
    "my project",
    "my college",
)

# Full phrases only — prevents single words like "notes", "summary" misfiring
SUMMARY_HINTS = (
    "summarize this video",
    "summarise this video",
    "summarize the video",
    "summarise the video",
    "give me a summary",
    "give a summary",
    "video summary",
    "full summary",
    "complete summary",
    "overview of the video",
    "what is this video about",
    "what's this video about",
    "generate notes",
    "generate study notes",
    "timeline of the video",
    "topics covered in the video",
    "key moments in the video",
    "chapters of the video",
    "questions discussed in the video",
    "main points of the video",
)

# Full phrases only — prevents "quiz" inside a question misfiring
VIDEO_TASK_HINTS = (
    "generate quiz",
    "create quiz",
    "make quiz",
    "prepare quiz",
    "generate mcq",
    "create mcq",
    "prepare mcq",
    "generate flashcards",
    "create flashcards",
    "generate interview questions",
    "create interview questions",
    "prepare interview questions",
    "generate practice questions",
    "create practice questions",
    "generate revision notes",
    "create revision notes",
    "generate cheat sheet",
    "create cheat sheet",
    "prepare notes",
)

GENERAL_HINTS = (
    "write code",
    "generate code",
    "python code",
    "java code",
    "c++ code",
    "javascript code",
    "sql query",
    "leetcode",
    "resume",
    "linkedin",
    "cover letter",
    "essay",
    "joke",
    "email",
    "fibonacci",
    "prime number",
    "merge sort",
    "quick sort",
    "binary search code",
)

FOLLOWUP_HINTS = (
    "this",
    "that",
    "it",
    "why",
    "how",
    "more",
    "continue",
    "elaborate",
    "example",
    "explain more",
    "give example",
    "in detail",
)


def classify_query(
    question,
    has_loaded_videos=False,
    previous_route=None,
):
    q = question.lower().strip()

    # MEMORY — always highest priority
    if any(hint in q for hint in MEMORY_HINTS):
        return "MEMORY"

    # SUMMARY — only when videos loaded AND explicit full phrase used
    if has_loaded_videos and any(hint in q for hint in SUMMARY_HINTS):
        return "VIDEO_SUMMARY"

    # VIDEO TASK — only when videos loaded AND explicit full phrase used
    if has_loaded_videos and any(hint in q for hint in VIDEO_TASK_HINTS):
        return "VIDEO_TASK"

    # GENERAL — code, jokes, essays etc. regardless of loaded videos
    if any(hint in q for hint in GENERAL_HINTS):
        return "GENERAL"

    # FOLLOWUP — short follow-up inherits previous route
    if previous_route is not None and len(q.split()) <= 6:
        if any(hint in q for hint in FOLLOWUP_HINTS):
            return previous_route

    # VIDEO QA — default when a video is loaded
    if has_loaded_videos:
        return "VIDEO_QA"

    # DEFAULT — no video loaded, treat as general chat
    return "GENERAL"
